# Flex Linx Graphics — Asset Guide

This folder holds every image the site expects. Until real photography is
added, the site shows a tasteful textured placeholder (with a filename
label) wherever an image belongs — never a broken-image icon.

## Logo
- `logo.png` — replace this file directly with your official logo (transparent
  background recommended). No code changes are needed; every page references
  this same file.

## Folders
- `/hero/` — homepage hero slider images: `hero-1.jpg`, `hero-2.jpg`, `hero-3.jpg` (add more and update the slide markup in `index.html` if needed)
- `/products/` — product photography, referenced from `js/products.js`
- `/categories/` — category card + showcase images (canvas / wallpaper / neon)
- `/ceo/` — `ceo.jpg`, the CEO portrait used on the homepage and About page
- `/banners/` — "Transform Your Space" and promotional banner images
- `/reviews/` — optional customer photos for the reviews carousel
- `/community/` — real customer photography for the community showcase grid

## How placeholders work
Every placeholder is a `<div class="ph">` block styled in `css/style.css`.
To swap one for a real photo, replace its inner content with an `<img>` tag
pointing at the matching file in this folder — the surrounding layout,
rounding and hover effects stay the same.
