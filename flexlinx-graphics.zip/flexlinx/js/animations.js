/* ==========================================================================
   FLEX LINX GRAPHICS — Animations
   Scroll reveals, sticky header state, marquee duplication.
   ========================================================================== */

(function(){
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Duplicate marquee content once so the loop is seamless.
  document.querySelectorAll('.announce__track').forEach(track => {
    track.innerHTML += track.innerHTML;
    if(reduced) track.style.animation = 'none';
  });

  // Sticky header state on scroll.
  const header = document.querySelector('.site-header');
  const onScroll = () => {
    if(!header) return;
    header.classList.toggle('is-scrolled', window.scrollY > 12);
    const btt = document.querySelector('.back-to-top');
    if(btt) btt.classList.toggle('show', window.scrollY > 500);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // Reveal-on-scroll for elements marked .reveal / .reveal-group / .trust-item
  const targets = document.querySelectorAll('.reveal, .reveal-group, .trust-item');
  if(reduced || !('IntersectionObserver' in window)){
    targets.forEach(el => el.classList.add('in-view'));
  } else {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if(entry.isIntersecting){
          entry.target.classList.add('in-view');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
    targets.forEach(el => io.observe(el));
  }
})();
