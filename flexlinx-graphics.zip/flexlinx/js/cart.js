/* ==========================================================================
   FLEX LINX GRAPHICS — Cart
   Frontend-only cart persisted to localStorage. Structured so the storage
   layer (CartStore) can later be swapped for a real Shopify cart API
   without touching the render functions in main.js.
   ========================================================================== */

const CART_KEY = 'flexlinx_cart_v1';

const CartStore = {
  read(){
    try{ return JSON.parse(localStorage.getItem(CART_KEY)) || []; }
    catch(e){ return []; }
  },
  write(items){
    try{ localStorage.setItem(CART_KEY, JSON.stringify(items)); }
    catch(e){ /* storage unavailable — cart will not persist this session */ }
    document.dispatchEvent(new CustomEvent('cart:changed', { detail: items }));
  }
};

const Cart = {
  getItems(){ return CartStore.read(); },

  add(product, qty = 1, optionLabel = ''){
    const items = CartStore.read();
    const lineId = product.id + (optionLabel ? '::' + optionLabel : '');
    const existing = items.find(i => i.lineId === lineId);
    if(existing){ existing.qty += qty; }
    else{
      items.push({
        lineId, id: product.id, slug: product.slug, name: product.name,
        price: product.price, category: product.category, optionLabel,
        qty, thumb: product.images[0]
      });
    }
    CartStore.write(items);
    return items;
  },

  updateQty(lineId, qty){
    let items = CartStore.read();
    if(qty <= 0){ items = items.filter(i => i.lineId !== lineId); }
    else{ items = items.map(i => i.lineId === lineId ? { ...i, qty } : i); }
    CartStore.write(items);
    return items;
  },

  remove(lineId){
    const items = CartStore.read().filter(i => i.lineId !== lineId);
    CartStore.write(items);
    return items;
  },

  clear(){ CartStore.write([]); },

  count(){ return CartStore.read().reduce((sum, i) => sum + i.qty, 0); },

  subtotal(){ return CartStore.read().reduce((sum, i) => sum + i.qty * i.price, 0); }
};
