/* ==========================================================================
   FLEX LINX GRAPHICS — Product Data
   Single source of truth for all product info used across pages.
   Replace / extend this array to update the whole site — no UI file
   needs to change. Each product's `images` array holds placeholder
   keys; drop real photography into /assets/products/ and swap the
   `img` path in once real assets are ready (see comment at bottom).
   ========================================================================== */

const CATEGORY_META = {
  canvas: { label: 'Canvas Frames', icon: 'frame', url: 'shop.html?category=canvas' },
  wallpaper: { label: '3D Wallpapers', icon: 'wallpaper', url: 'shop.html?category=wallpaper' },
  neon: { label: 'Neon Custom Boards', icon: 'neon', url: 'shop.html?category=neon' }
};

const PRODUCTS = [
  {
    id: 'p1',
    slug: 'custom-memory-canvas-frame',
    name: 'Custom Memory Frame',
    category: 'canvas',
    price: 2499,
    oldPrice: 3499,
    rating: 4.8,
    ratingCount: 132,
    stock: true,
    isDemo: true,
    badges: ['Bestseller'],
    images: ['canvas-1', 'canvas-2', 'canvas-3'],
    shortDesc: 'A framed canvas print made from your own photo, stretched over a solid wooden frame.',
    description: 'Turn any photo into a gallery-quality canvas print. Each frame is printed on premium canvas fabric and stretched over a kiln-dried wooden frame so it stays flat for years. Ready to hang, straight out of the box.',
    options: { size: ['12x18"', '16x24"', '24x36"'], style: ['Classic', 'Split 3-Panel'] },
    specs: { 'Material': 'Premium canvas fabric', 'Frame': 'Kiln-dried wood', 'Finish': 'Matte UV-protected', 'Mounting': 'Ready-to-hang hooks included', 'Customization': 'Upload any photo' }
  },
  {
    id: 'p2',
    slug: 'luxury-marble-3d-wallpaper',
    name: 'Luxury Marble 3D Wallpaper',
    category: 'wallpaper',
    price: 3999,
    oldPrice: 5499,
    rating: 4.7,
    ratingCount: 98,
    stock: true,
    isDemo: true,
    badges: ['New'],
    images: ['wallpaper-1', 'wallpaper-2', 'wallpaper-3'],
    shortDesc: 'A raised-texture 3D wallpaper panel with a marble finish, sold per panel.',
    description: 'A textured 3D wall panel that brings a marble-effect finish to any room without the cost or weight of real stone. Panels install edge-to-edge for a seamless feature wall.',
    options: { size: ['1x1 m panel', '1x2 m panel'], finish: ['Matte', 'Glossy'] },
    specs: { 'Material': 'PVC foam 3D panel', 'Coverage': 'Sold per panel', 'Installation': 'Wall adhesive (not included)', 'Finish': 'Marble-effect', 'Customization': 'Size on request' }
  },
  {
    id: 'p3',
    slug: 'custom-led-neon-name-board',
    name: 'Custom LED Neon Name Board',
    category: 'neon',
    price: 4499,
    oldPrice: 6499,
    rating: 4.9,
    ratingCount: 211,
    stock: true,
    isDemo: true,
    badges: ['Bestseller', 'Customizable'],
    images: ['neon-1', 'neon-2', 'neon-3'],
    shortDesc: 'A custom-shaped LED neon sign with your name or text, mounted on an acrylic backboard.',
    description: 'Your name, brand or favorite word — bent into a soft-glow LED neon sign and mounted on a clear acrylic backboard. Runs cool, uses very little power, and comes with a wall-mount kit.',
    options: { color: ['Warm White', 'Pink', 'Blue', 'Multicolor'], size: ['Small (30cm)', 'Medium (45cm)', 'Large (60cm)'] },
    specs: { 'Light source': 'Flexible LED neon', 'Backboard': 'Clear acrylic', 'Power': 'Low-voltage adapter included', 'Lifespan': 'Long-life LED', 'Customization': 'Any text/shape on request' }
  },
  {
    id: 'p4',
    slug: 'panoramic-nature-canvas-set',
    name: 'Panoramic Nature Canvas Set',
    category: 'canvas',
    price: 3299,
    oldPrice: null,
    rating: 4.6,
    ratingCount: 64,
    stock: true,
    isDemo: true,
    badges: [],
    images: ['canvas-2', 'canvas-1', 'canvas-3'],
    shortDesc: 'A 3-panel canvas set designed to form one wide panoramic scene.',
    description: 'Three coordinated canvas panels that combine into one wide panoramic scene. Works beautifully above a sofa, bed, or dining table.',
    options: { size: ['3x 12x16"', '3x 16x20"'], style: ['Landscape', 'Abstract'] },
    specs: { 'Material': 'Premium canvas fabric', 'Panels': '3-piece set', 'Finish': 'Matte UV-protected', 'Mounting': 'Ready-to-hang hooks included' }
  },
  {
    id: 'p5',
    slug: 'geometric-3d-brick-wallpaper',
    name: 'Geometric 3D Brick Wallpaper',
    category: 'wallpaper',
    price: 3599,
    oldPrice: 4299,
    rating: 4.5,
    ratingCount: 47,
    stock: true,
    isDemo: true,
    badges: ['Sale'],
    images: ['wallpaper-2', 'wallpaper-3', 'wallpaper-1'],
    shortDesc: 'A textured 3D wall panel with a raised brick pattern.',
    description: 'A raised brick-pattern wall panel for an industrial-modern accent wall — light enough to install without structural work.',
    options: { size: ['1x1 m panel', '1x2 m panel'], finish: ['Grey', 'White', 'Terracotta'] },
    specs: { 'Material': 'PVC foam 3D panel', 'Coverage': 'Sold per panel', 'Installation': 'Wall adhesive (not included)', 'Finish': 'Brick-effect' }
  },
  {
    id: 'p6',
    slug: 'custom-logo-neon-sign',
    name: 'Custom Logo Neon Sign',
    category: 'neon',
    price: 5999,
    oldPrice: null,
    rating: 4.8,
    ratingCount: 39,
    stock: true,
    isDemo: true,
    badges: ['Customizable'],
    images: ['neon-2', 'neon-3', 'neon-1'],
    shortDesc: 'A custom-shaped LED neon sign built from your logo or artwork.',
    description: 'Built to match your brand or business logo, this LED neon sign is ideal for shopfronts, studios and home offices.',
    options: { color: ['Warm White', 'Pink', 'Blue', 'Multicolor'], size: ['Medium (45cm)', 'Large (60cm)', 'XL (90cm)'] },
    specs: { 'Light source': 'Flexible LED neon', 'Backboard': 'Clear acrylic', 'Power': 'Low-voltage adapter included', 'Customization': 'Any logo/artwork on request' }
  },
  {
    id: 'p7',
    slug: 'minimalist-line-art-canvas',
    name: 'Minimalist Line Art Canvas',
    category: 'canvas',
    price: 1899,
    oldPrice: 2299,
    rating: 4.4,
    ratingCount: 58,
    stock: true,
    isDemo: true,
    badges: ['Sale'],
    images: ['canvas-3', 'canvas-2', 'canvas-1'],
    shortDesc: 'A single-panel canvas print in a minimalist line-art style.',
    description: 'A clean, single-line canvas print that suits modern, minimalist interiors. Available in a range of ready-made line-art designs, or send your own.',
    options: { size: ['12x18"', '16x24"'], style: ['Portrait', 'Botanical', 'Abstract'] },
    specs: { 'Material': 'Premium canvas fabric', 'Frame': 'Kiln-dried wood', 'Finish': 'Matte UV-protected' }
  },
  {
    id: 'p8',
    slug: 'stone-texture-3d-wallpaper',
    name: 'Stone Texture 3D Wallpaper',
    category: 'wallpaper',
    price: 4299,
    oldPrice: null,
    rating: 4.6,
    ratingCount: 31,
    stock: true,
    isDemo: true,
    badges: ['New'],
    images: ['wallpaper-3', 'wallpaper-1', 'wallpaper-2'],
    shortDesc: 'A raised-texture 3D wallpaper panel with a natural stone finish.',
    description: 'A deep-textured wall panel that mimics natural stone cladding, ideal for feature walls, cafes and studios.',
    options: { size: ['1x1 m panel', '1x2 m panel'], finish: ['Grey Stone', 'Sandstone'] },
    specs: { 'Material': 'PVC foam 3D panel', 'Coverage': 'Sold per panel', 'Installation': 'Wall adhesive (not included)' }
  }
];

const REVIEWS = [
  { name: 'Ayesha K.', initials: 'AK', rating: 5, product: 'Custom LED Neon Name Board', text: 'Ordered a neon sign with my daughter\u2019s name for her room — the glow and finish look far more premium than the price suggests.' },
  { name: 'Hamza R.', initials: 'HR', rating: 5, product: 'Custom Memory Frame', text: 'Printed our wedding photo on canvas and it arrived well packed with no color distortion. Looks great above the sofa.' },
  { name: 'Sana M.', initials: 'SM', rating: 4, product: 'Luxury Marble 3D Wallpaper', text: 'The texture is really nice in person. Installation took a bit of patience but the end result is worth it.' },
  { name: 'Bilal T.', initials: 'BT', rating: 5, product: 'Custom Logo Neon Sign', text: 'Got this made for my small studio. Delivery across Pakistan was faster than I expected.' },
  { name: 'Mahnoor F.', initials: 'MF', rating: 5, product: 'Geometric 3D Brick Wallpaper', text: 'Coordinated the whole order over WhatsApp which made customizing the size very easy.' }
];
/* NOTE: reviews above are demo/sample content used to preview the layout —
   replace with real, verified customer reviews before launch. */

const ICONS = {
  frame: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 15l5-5 4 4 3-3 6 6" stroke-linecap="round" stroke-linejoin="round"/><circle cx="8.5" cy="8.5" r="1.5"/></svg>',
  wallpaper: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 21V9l6-6 6 6v12M9 21V13h6v8" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 9l6-6" stroke-linecap="round"/></svg>',
  neon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M6 3a3 3 0 100 6h5a3 3 0 110 6H5" stroke-linecap="round"/><circle cx="18" cy="18" r="3"/></svg>'
};

/** Build the reusable placeholder-media block used everywhere a real photo
 *  will eventually go. Keeps a consistent look until /assets is populated. */
function phMedia(categoryKey, label){
  const icon = ICONS[categoryKey] || ICONS.frame;
  return `<div class="ph"><span class="ph__icon">${icon}</span>${label ? `<span class="ph__label">${label}</span>` : ''}</div>`;
}

function getProductBySlug(slug){ return PRODUCTS.find(p => p.slug === slug); }
function getProductsByCategory(cat){ return cat ? PRODUCTS.filter(p => p.category === cat) : PRODUCTS; }
function formatPrice(n){ return 'Rs. ' + Number(n).toLocaleString('en-PK'); }

function starsHTML(rating){
  const full = Math.round(rating);
  let html = '<span class="stars">';
  for(let i=0;i<5;i++){
    html += `<svg viewBox="0 0 20 20" fill="${i<full?'currentColor':'none'}" stroke="currentColor" stroke-width="1"><path d="M10 1.5l2.6 5.3 5.9.8-4.3 4.1 1 5.8L10 14.7l-5.2 2.8 1-5.8L1.5 7.6l5.9-.8z"/></svg>`;
  }
  html += '</span>';
  return html;
}
