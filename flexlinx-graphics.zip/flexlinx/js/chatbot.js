/* ==========================================================================
   FLEX LINX GRAPHICS — Chatbot (frontend prototype)
   This answers a fixed set of store FAQs by keyword matching. It is NOT
   connected to any AI model or backend. The response function is isolated
   (getBotReply) so a real AI API could be wired in later without touching
   the UI code in this file.
   ========================================================================== */

const CHAT_RULES = [
  { keys: ['deliver', 'lahore', 'karachi', 'islamabad', 'pakistan', 'shipping'], reply: 'Yes, Flex Linx Graphics delivers across Pakistan.' },
  { keys: ['cod', 'cash on delivery'], reply: 'Cash on Delivery is available, with half payment required in advance to confirm your order.' },
  { keys: ['advance', 'payment', 'half payment'], reply: 'We ask for half payment in advance to confirm custom orders, with the remaining balance due as Cash on Delivery.' },
  { keys: ['neon'], reply: 'Yes. You can order a custom Neon Board with your own text, name or logo — contact us on WhatsApp with your requirements.' },
  { keys: ['canvas', 'frame'], reply: 'We offer custom Canvas Frames made from any photo you send us — just choose a size and share your image.' },
  { keys: ['wallpaper', '3d wallpaper'], reply: 'Yes, our 3D Wallpapers can be customized by finish and panel size. Message us on WhatsApp for details.' },
  { keys: ['custom', 'customi'], reply: 'All three product lines — Canvas Frames, 3D Wallpapers and Neon Boards — can be customized. Share your idea on WhatsApp and we\u2019ll guide you.' },
  { keys: ['whatsapp', 'contact', 'phone', 'number'], reply: 'You can reach Flex Linx Graphics on WhatsApp at +92 329 1080411, or email flexlinxb2@gmail.com.' },
  { keys: ['price', 'cost', 'rate'], reply: 'Prices are shown on each product page. For custom sizes or designs, WhatsApp us for an exact quote.' },
  { keys: ['return', 'refund', 'exchange'], reply: 'For custom-made items, please confirm details carefully before ordering. For any issue with your order, reach us on WhatsApp and our team will help.' },
  { keys: ['track', 'order status'], reply: 'For order tracking, please message us on WhatsApp with your order details and we\u2019ll update you directly.' },
  { keys: ['hi', 'hello', 'salam', 'assalam'], reply: 'Hello! I\u2019m the Flex Linx Graphics assistant. Ask me about delivery, COD, custom orders or our products.' }
];

const CHAT_FALLBACK = 'I can help with questions about delivery, Cash on Delivery, custom orders and our products. For anything else, please WhatsApp Flex Linx Graphics at +92 329 1080411.';

function getBotReply(message){
  const m = message.toLowerCase();
  const hit = CHAT_RULES.find(rule => rule.keys.some(k => m.includes(k)));
  return hit ? hit.reply : CHAT_FALLBACK;
}

const CHAT_SUGGESTIONS = [
  'Do you deliver to Lahore?',
  'Is COD available?',
  'Can I order a custom neon board?',
  'How much is the advance payment?'
];
