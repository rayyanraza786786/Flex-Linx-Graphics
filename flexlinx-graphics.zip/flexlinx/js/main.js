/* ==========================================================================
   FLEX LINX GRAPHICS — Main
   Wires together intro, header/drawers, hero slider, product grids,
   quick view, FAQ, WhatsApp, chatbot UI and toasts. Depends on
   products.js, cart.js, wishlist.js, search.js, chatbot.js loading first.
   ========================================================================== */

const WHATSAPP_NUMBER = '923291080411';

function waLink(message){
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

document.addEventListener('DOMContentLoaded', () => {
  initIntro();
  initHeaderNav();
  initMobileDrawer();
  initCartDrawer();
  initSearchOverlay();
  initHeroSlider();
  initFAQ();
  initQuickView();
  initProductTabs();
  initChatbot();
  initWhatsAppLinks();
  initBackToTop();
  renderAllProductGrids();
  updateCartBadge();
  updateWishlistBadge();
  bindWishlistButtons();
  bindAddToCartButtons();
  highlightActiveNav();

  document.addEventListener('cart:changed', updateCartBadge);
  document.addEventListener('cart:changed', renderCartDrawer);
  document.addEventListener('wishlist:changed', updateWishlistBadge);
  document.addEventListener('wishlist:changed', bindWishlistButtons);
});

/* -------------------------------------------------------------------- */
/* Intro                                                                  */
/* -------------------------------------------------------------------- */
function initIntro(){
  const intro = document.querySelector('.intro');
  if(!intro) return;
  const seen = sessionStorage.getItem('flexlinx_intro_seen');
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(seen || reduced){
    intro.classList.add('is-hidden');
    return;
  }
  sessionStorage.setItem('flexlinx_intro_seen', '1');
  setTimeout(() => intro.classList.add('is-hidden'), 2000);
}

/* -------------------------------------------------------------------- */
/* Header / nav                                                          */
/* -------------------------------------------------------------------- */
function initHeaderNav(){
  const searchBtn = document.querySelector('[data-open-search]');
  if(searchBtn) searchBtn.addEventListener('click', () => toggleOverlay('.search-overlay', true, '#searchInput'));
}

function highlightActiveNav(){
  const path = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.main-nav a, .mobile-drawer__nav a').forEach(a => {
    const href = a.getAttribute('href').split('?')[0];
    if(href === path) a.classList.add('active');
  });
}

/* -------------------------------------------------------------------- */
/* Mobile drawer                                                         */
/* -------------------------------------------------------------------- */
function initMobileDrawer(){
  const drawer = document.querySelector('.mobile-drawer');
  const overlay = document.querySelector('[data-drawer-overlay]');
  const openBtn = document.querySelector('[data-open-menu]');
  const closeBtn = document.querySelector('[data-close-menu]');
  if(!drawer) return;
  const open = () => { drawer.classList.add('is-open'); overlay.classList.add('is-open'); document.body.style.overflow = 'hidden'; };
  const close = () => { drawer.classList.remove('is-open'); overlay.classList.remove('is-open'); document.body.style.overflow = ''; };
  openBtn?.addEventListener('click', open);
  closeBtn?.addEventListener('click', close);
  overlay?.addEventListener('click', close);
}

/* -------------------------------------------------------------------- */
/* Cart drawer                                                           */
/* -------------------------------------------------------------------- */
function initCartDrawer(){
  const drawer = document.querySelector('.cart-drawer');
  if(!drawer) return;
  const overlay = document.querySelector('[data-cart-overlay]');
  document.querySelectorAll('[data-open-cart]').forEach(btn => btn.addEventListener('click', (e) => {
    e.preventDefault();
    drawer.classList.add('is-open'); overlay.classList.add('is-open'); document.body.style.overflow = 'hidden';
  }));
  document.querySelectorAll('[data-close-cart]').forEach(btn => btn.addEventListener('click', closeCartDrawer));
  overlay?.addEventListener('click', closeCartDrawer);
  renderCartDrawer();
}
function closeCartDrawer(){
  document.querySelector('.cart-drawer')?.classList.remove('is-open');
  document.querySelector('[data-cart-overlay]')?.classList.remove('is-open');
  document.body.style.overflow = '';
}

function renderCartDrawer(){
  const wrap = document.getElementById('cartDrawerItems');
  const footWrap = document.getElementById('cartDrawerFoot');
  if(!wrap) return;
  const items = Cart.getItems();

  if(items.length === 0){
    wrap.innerHTML = `<div class="cart-empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 002 1.6h9.7a2 2 0 002-1.6L23 6H6"/></svg><p>Your cart is empty.</p></div>`;
    if(footWrap) footWrap.innerHTML = '';
    return;
  }

  wrap.innerHTML = items.map(i => `
    <div class="cart-line" data-line="${i.lineId}">
      <div class="cart-line__img">${phMedia(i.category)}</div>
      <div class="cart-line__body">
        <div class="cart-line__title">${i.name}</div>
        <div class="cart-line__meta">${i.optionLabel || ''} ${formatPrice(i.price)}</div>
        <div class="cart-line__row">
          <div class="qty-stepper">
            <button data-qty="-1" aria-label="Decrease quantity">\u2212</button>
            <span>${i.qty}</span>
            <button data-qty="1" aria-label="Increase quantity">+</button>
          </div>
          <button class="cart-line__remove" data-remove-line>Remove</button>
        </div>
      </div>
    </div>`).join('');

  wrap.querySelectorAll('[data-qty]').forEach(btn => btn.addEventListener('click', () => {
    const lineId = btn.closest('[data-line]').dataset.line;
    const delta = parseInt(btn.dataset.qty, 10);
    const current = Cart.getItems().find(i => i.lineId === lineId);
    if(current) Cart.updateQty(lineId, current.qty + delta);
  }));
  wrap.querySelectorAll('[data-remove-line]').forEach(btn => btn.addEventListener('click', () => {
    const lineId = btn.closest('[data-line]').dataset.line;
    Cart.remove(lineId);
    showToast('Removed from cart');
  }));

  if(footWrap){
    footWrap.innerHTML = `
      <div class="cart-subtotal-row"><span>Subtotal</span><span>${formatPrice(Cart.subtotal())}</span></div>
      <a href="cart.html" class="btn btn-outline btn-block" style="margin-bottom:10px;">View Cart</a>
      <a href="cart.html" class="btn btn-primary btn-block">Checkout</a>
      <p style="font-size:12px;color:var(--ink-soft);text-align:center;margin-top:10px;">Cash on Delivery \u00b7 Half payment advance</p>`;
  }
}

function updateCartBadge(){
  document.querySelectorAll('[data-cart-count]').forEach(el => { el.textContent = Cart.count() || ''; });
}

/* -------------------------------------------------------------------- */
/* Add to cart / Buy now / Wishlist buttons (product cards & PDP)        */
/* -------------------------------------------------------------------- */
function bindAddToCartButtons(){
  document.querySelectorAll('[data-add-cart]').forEach(btn => {
    if(btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const slug = btn.dataset.addCart;
      const product = getProductBySlug(slug);
      if(!product) return;
      Cart.add(product, 1);
      showToast(`${product.name} added to cart`);
      animateCartIcon();
    });
  });
  document.querySelectorAll('[data-buy-now]').forEach(btn => {
    if(btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const slug = btn.dataset.buyNow;
      const product = getProductBySlug(slug);
      if(!product) return;
      Cart.add(product, 1);
      window.location.href = 'cart.html';
    });
  });
}

function bindWishlistButtons(){
  document.querySelectorAll('[data-wishlist]').forEach(btn => {
    const id = btn.dataset.wishlist;
    btn.classList.toggle('active', Wishlist.has(id));
    if(btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const isNow = Wishlist.toggle(id);
      btn.classList.toggle('active', isNow);
      showToast(isNow ? 'Added to wishlist' : 'Removed from wishlist');
    });
  });
}
function updateWishlistBadge(){
  document.querySelectorAll('[data-wishlist-count]').forEach(el => { el.textContent = Wishlist.count() || ''; });
}

function animateCartIcon(){
  const icon = document.querySelector('[data-open-cart] svg');
  if(!icon) return;
  icon.style.transition = 'transform .3s ease';
  icon.style.transform = 'scale(1.35)';
  setTimeout(() => { icon.style.transform = 'scale(1)'; }, 300);
}

/* -------------------------------------------------------------------- */
/* Toasts                                                                */
/* -------------------------------------------------------------------- */
function showToast(message){
  let stack = document.querySelector('.toast-stack');
  if(!stack){
    stack = document.createElement('div');
    stack.className = 'toast-stack';
    document.body.appendChild(stack);
  }
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5" stroke-linecap="round" stroke-linejoin="round"/></svg><span>${message}</span>`;
  stack.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 2600);
}

/* -------------------------------------------------------------------- */
/* Search overlay                                                        */
/* -------------------------------------------------------------------- */
function initSearchOverlay(){
  const overlay = document.querySelector('.search-overlay');
  if(!overlay) return;
  const input = document.getElementById('searchInput');
  document.querySelectorAll('[data-close-search]').forEach(btn => btn.addEventListener('click', () => toggleOverlay('.search-overlay', false)));
  overlay.addEventListener('click', (e) => { if(e.target === overlay) toggleOverlay('.search-overlay', false); });
  input?.addEventListener('input', () => renderSearchResults(input.value));
  renderSearchResults('');
  document.addEventListener('keydown', (e) => { if(e.key === 'Escape') toggleOverlay('.search-overlay', false); });
}
function toggleOverlay(selector, open, focusSelector){
  const el = document.querySelector(selector);
  if(!el) return;
  el.classList.toggle('is-open', open);
  document.body.style.overflow = open ? 'hidden' : '';
  if(open && focusSelector) setTimeout(() => document.querySelector(focusSelector)?.focus(), 250);
}

/* -------------------------------------------------------------------- */
/* Hero slider                                                           */
/* -------------------------------------------------------------------- */
function initHeroSlider(){
  const hero = document.querySelector('.hero');
  if(!hero) return;
  const track = hero.querySelector('.hero__track');
  const slides = hero.querySelectorAll('.hero__slide');
  const dotsWrap = hero.querySelector('.hero__dots');
  let index = 0, timer;

  slides.forEach((_, i) => {
    const dot = document.createElement('button');
    if(i === 0) dot.classList.add('active');
    dot.addEventListener('click', () => go(i));
    dotsWrap.appendChild(dot);
  });
  const dots = dotsWrap.querySelectorAll('button');

  function go(i){
    index = (i + slides.length) % slides.length;
    track.style.transform = `translateX(-${index * 100}%)`;
    dots.forEach((d, di) => d.classList.toggle('active', di === index));
  }
  function next(){ go(index + 1); }
  function prev(){ go(index - 1); }
  function restart(){ clearInterval(timer); timer = setInterval(next, 5000); }

  hero.querySelector('.hero__nav--next')?.addEventListener('click', () => { next(); restart(); });
  hero.querySelector('.hero__nav--prev')?.addEventListener('click', () => { prev(); restart(); });

  // swipe
  let startX = 0;
  track.addEventListener('touchstart', (e) => { startX = e.touches[0].clientX; }, { passive: true });
  track.addEventListener('touchend', (e) => {
    const diff = e.changedTouches[0].clientX - startX;
    if(Math.abs(diff) > 40){ diff > 0 ? prev() : next(); restart(); }
  }, { passive: true });

  hero.addEventListener('mouseenter', () => clearInterval(timer));
  hero.addEventListener('mouseleave', restart);
  restart();
}

/* -------------------------------------------------------------------- */
/* FAQ accordion                                                         */
/* -------------------------------------------------------------------- */
function initFAQ(){
  document.querySelectorAll('.faq-item').forEach(item => {
    const q = item.querySelector('.faq-q');
    const a = item.querySelector('.faq-a');
    q.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');
      item.parentElement.querySelectorAll('.faq-item').forEach(i => {
        i.classList.remove('open');
        i.querySelector('.faq-a').style.maxHeight = null;
      });
      if(!isOpen){
        item.classList.add('open');
        a.style.maxHeight = a.scrollHeight + 'px';
      }
    });
  });
}

/* -------------------------------------------------------------------- */
/* Product tabs (PDP)                                                    */
/* -------------------------------------------------------------------- */
function initProductTabs(){
  document.querySelectorAll('.pd-tab-btns button').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      btn.parentElement.querySelectorAll('button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.pd-tab-panel').forEach(p => p.classList.toggle('active', p.dataset.tab === target));
    });
  });
}

/* -------------------------------------------------------------------- */
/* Quick View modal                                                      */
/* -------------------------------------------------------------------- */
function initQuickView(){
  const overlay = document.querySelector('.modal-overlay');
  if(!overlay) return;
  document.body.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-quickview]');
    if(!btn) return;
    e.preventDefault();
    openQuickView(btn.dataset.quickview);
  });
  overlay.addEventListener('click', (e) => { if(e.target === overlay) closeQuickView(); });
  overlay.querySelector('[data-close-quickview]')?.addEventListener('click', closeQuickView);
  document.addEventListener('keydown', (e) => { if(e.key === 'Escape') closeQuickView(); });
}
function openQuickView(slug){
  const product = getProductBySlug(slug);
  if(!product) return;
  const overlay = document.querySelector('.modal-overlay');
  overlay.querySelector('.quickview-modal__media').innerHTML = phMedia(product.category);
  overlay.querySelector('[data-qv-name]').textContent = product.name;
  overlay.querySelector('[data-qv-desc]').textContent = product.shortDesc;
  overlay.querySelector('[data-qv-price]').innerHTML = `${formatPrice(product.price)} ${product.oldPrice ? `<span class="price-old">${formatPrice(product.oldPrice)}</span>` : ''}`;
  overlay.querySelector('[data-qv-rating]').innerHTML = starsHTML(product.rating) + ` <span style="color:var(--ink-soft);font-size:12.5px;">(${product.ratingCount})</span>`;
  const addBtn = overlay.querySelector('[data-qv-add]');
  addBtn.dataset.addCart = product.slug;
  addBtn.dataset.bound = '';
  overlay.querySelector('[data-qv-link]').href = `product.html?slug=${product.slug}`;
  overlay.classList.add('is-open');
  document.body.style.overflow = 'hidden';
  bindAddToCartButtons();
}
function closeQuickView(){
  document.querySelector('.modal-overlay')?.classList.remove('is-open');
  document.body.style.overflow = '';
}

/* -------------------------------------------------------------------- */
/* WhatsApp links                                                        */
/* -------------------------------------------------------------------- */
function initWhatsAppLinks(){
  document.querySelectorAll('[data-wa-general]').forEach(a => {
    a.href = waLink('Hello Flex Linx Graphics, I found you through your website and would like to know more about your products.');
  });
  document.querySelectorAll('[data-wa-product]').forEach(a => {
    const name = a.dataset.waProduct;
    a.href = waLink(`Hello Flex Linx Graphics, I am interested in ${name}. I found this product on your website.`);
  });
}

/* -------------------------------------------------------------------- */
/* Chatbot                                                                */
/* -------------------------------------------------------------------- */
function initChatbot(){
  const panel = document.querySelector('.chat-panel');
  const fab = document.querySelector('.fab-chat');
  if(!panel || !fab) return;
  const body = panel.querySelector('.chat-panel__body');
  const input = panel.querySelector('input');
  const form = panel.querySelector('.chat-panel__input');
  const suggestWrap = panel.querySelector('.chat-suggestions');

  fab.addEventListener('click', () => panel.classList.toggle('is-open'));
  panel.querySelector('[data-close-chat]')?.addEventListener('click', () => panel.classList.remove('is-open'));

  suggestWrap.innerHTML = CHAT_SUGGESTIONS.map(s => `<button class="chat-chip">${s}</button>`).join('');
  suggestWrap.querySelectorAll('.chat-chip').forEach(chip => chip.addEventListener('click', () => sendMsg(chip.textContent)));

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if(!input.value.trim()) return;
    sendMsg(input.value.trim());
    input.value = '';
  });

  function sendMsg(text){
    appendMsg(text, 'user');
    setTimeout(() => appendMsg(getBotReply(text), 'bot'), 400);
  }
  function appendMsg(text, role){
    const div = document.createElement('div');
    div.className = `chat-msg ${role}`;
    div.textContent = text;
    body.appendChild(div);
    body.scrollTop = body.scrollHeight;
  }
}

/* -------------------------------------------------------------------- */
/* Back to top                                                           */
/* -------------------------------------------------------------------- */
function initBackToTop(){
  document.querySelector('.back-to-top')?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
}

/* -------------------------------------------------------------------- */
/* Product grid rendering                                                */
/* -------------------------------------------------------------------- */
function renderProductCard(product){
  const badges = product.badges.map(b => `<span class="badge-chip">${b}</span>`).join('');
  const demo = product.isDemo ? `<span class="badge-chip demo">Demo</span>` : '';
  return `
  <div class="product-card">
    <div class="product-card__media">
      <a href="product.html?slug=${product.slug}">${phMedia(product.category)}</a>
      <div class="product-card__badges">${badges}${demo}</div>
      <button class="wishlist-btn" data-wishlist="${product.id}" aria-label="Add to wishlist">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 21s-7.5-4.6-10-9.3C.4 8.1 2.3 4.5 6 4c2.2-.3 4.1.9 6 3 1.9-2.1 3.8-3.3 6-3 3.7.5 5.6 4.1 4 7.7C19.5 16.4 12 21 12 21z"/></svg>
      </button>
      <button class="quickview-btn" data-quickview="${product.slug}">Quick View</button>
    </div>
    <div class="product-card__body">
      <div class="product-card__cat">${CATEGORY_META[product.category].label}</div>
      <h3 class="product-card__title"><a href="product.html?slug=${product.slug}">${product.name}</a></h3>
      <div class="rating-row">${starsHTML(product.rating)} <span>(${product.ratingCount})</span></div>
      <div class="price-row">
        <span class="price">${formatPrice(product.price)}</span>
        ${product.oldPrice ? `<span class="price-old">${formatPrice(product.oldPrice)}</span>` : ''}
      </div>
      <button class="add-cart-btn" data-add-cart="${product.slug}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 002 1.6h9.7a2 2 0 002-1.6L23 6H6"/></svg>
        Add to Cart
      </button>
    </div>
  </div>`;
}

function renderAllProductGrids(){
  document.querySelectorAll('[data-product-grid]').forEach(grid => {
    const category = grid.dataset.category || '';
    const limit = parseInt(grid.dataset.limit || '8', 10);
    const excludeSlug = grid.dataset.exclude || '';
    let list = getProductsByCategory(category).filter(p => p.slug !== excludeSlug);
    list = list.slice(0, limit);
    grid.innerHTML = list.map(renderProductCard).join('');
  });
  bindWishlistButtons();
  bindAddToCartButtons();
}
