/* ==========================================================================
   FLEX LINX GRAPHICS — Wishlist
   ========================================================================== */

const WISHLIST_KEY = 'flexlinx_wishlist_v1';

const Wishlist = {
  read(){
    try{ return JSON.parse(localStorage.getItem(WISHLIST_KEY)) || []; }
    catch(e){ return []; }
  },
  write(ids){
    try{ localStorage.setItem(WISHLIST_KEY, JSON.stringify(ids)); }
    catch(e){ /* storage unavailable */ }
    document.dispatchEvent(new CustomEvent('wishlist:changed', { detail: ids }));
  },
  has(id){ return this.read().includes(id); },
  toggle(id){
    let ids = this.read();
    if(ids.includes(id)){ ids = ids.filter(i => i !== id); }
    else{ ids.push(id); }
    this.write(ids);
    return ids.includes(id);
  },
  count(){ return this.read().length; }
};
