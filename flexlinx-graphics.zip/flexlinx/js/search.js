/* ==========================================================================
   FLEX LINX GRAPHICS — Search
   ========================================================================== */

function searchProducts(query){
  const q = (query || '').trim().toLowerCase();
  if(!q) return { products: [], categories: [] };

  const products = PRODUCTS.filter(p =>
    p.name.toLowerCase().includes(q) ||
    p.shortDesc.toLowerCase().includes(q) ||
    p.category.toLowerCase().includes(q)
  ).slice(0, 6);

  const categories = Object.entries(CATEGORY_META)
    .filter(([key, meta]) => meta.label.toLowerCase().includes(q) || key.includes(q))
    .map(([key, meta]) => meta);

  return { products, categories };
}

function renderSearchResults(query){
  const wrap = document.getElementById('searchResults');
  if(!wrap) return;
  const { products, categories } = searchProducts(query);

  if(!query.trim()){
    wrap.innerHTML = `<div class="search-empty">Start typing to search Canvas Frames, 3D Wallpapers &amp; Neon Boards.</div>`;
    return;
  }
  if(products.length === 0 && categories.length === 0){
    wrap.innerHTML = `<div class="search-empty">No results for "${escapeHTML(query)}". Try "canvas", "wallpaper" or "neon".</div>`;
    return;
  }

  let html = '';
  categories.forEach(c => {
    html += `<a class="search-result" href="${c.url}"><div class="search-result__img">${phMedia(c.icon)}</div><div><strong>${c.label}</strong><div style="font-size:12px;color:var(--ink-soft)">Category</div></div></a>`;
  });
  products.forEach(p => {
    html += `<a class="search-result" href="product.html?slug=${p.slug}"><div class="search-result__img">${phMedia(p.category)}</div><div><strong>${p.name}</strong><div style="font-size:12px;color:var(--ink-soft)">${formatPrice(p.price)}</div></div></a>`;
  });
  wrap.innerHTML = html;
}

function escapeHTML(str){
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
